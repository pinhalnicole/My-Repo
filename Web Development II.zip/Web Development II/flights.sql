-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2017 at 02:57 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flights`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `flight_id` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Booking_date` datetime NOT NULL,
  `BookingID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`flight_id`, `UserID`, `Booking_date`, `BookingID`) VALUES
(6, 2, '2017-06-01 03:55:24', 16),
(8, 2, '2017-06-01 04:05:59', 17),
(8, 5, '2017-06-01 09:55:49', 18),
(6, 5, '2017-06-01 09:55:54', 19),
(10, 5, '2017-06-01 09:55:59', 20),
(7, 8, '2017-06-01 09:56:21', 21),
(9, 8, '2017-06-01 09:56:25', 22),
(10, 5, '2017-06-01 10:31:33', 23),
(7, 8, '2017-06-01 11:12:36', 24),
(9, 8, '2017-06-01 11:12:41', 25),
(10, 8, '2017-06-01 11:12:47', 26),
(9, 2, '2017-06-01 11:16:40', 27),
(13, 5, '2017-06-02 02:08:36', 28);

-- --------------------------------------------------------

--
-- Table structure for table `listings`
--

CREATE TABLE `listings` (
  `flight_id` int(11) NOT NULL,
  `flight_from` varchar(50) NOT NULL,
  `flight_to` varchar(50) NOT NULL,
  `depart_time` time NOT NULL,
  `arrival_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `listings`
--

INSERT INTO `listings` (`flight_id`, `flight_from`, `flight_to`, `depart_time`, `arrival_time`) VALUES
(6, 'Dublin', 'Madrid', '11:00:00', '13:45:00'),
(7, 'Milan', 'Amsterdam', '10:10:00', '10:55:00'),
(8, 'Lisbon', 'Cork', '12:00:00', '14:10:00'),
(9, 'Moscow', 'London', '12:00:00', '15:45:00'),
(10, 'Berlin', 'Dublin', '12:20:00', '14:34:00'),
(12, 'Madrid', 'Warsaw', '03:23:00', '05:08:00'),
(13, 'london', 'athens', '03:54:00', '04:54:00');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `mid` int(11) NOT NULL,
  `author` varchar(200) NOT NULL,
  `message` varchar(2000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`mid`, `author`, `message`) VALUES
(5, 'Nicole', 'My flight was late I want my money back!\r\nThank you...'),
(6, 'Mary', 'When will you open a route to South Africa?'),
(7, 'Hilary', 'You were brilliant!');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `u_name` varchar(50) NOT NULL,
  `u_surname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `username`, `password`, `u_name`, `u_surname`, `email`) VALUES
(1, 'admin', 'admin', 'joe', 'blog', ''),
(2, 'mary', 'mary', 'mary', 'scott', 'mary@email.com'),
(3, 'paul', 'paul', 'paul', 'smith', 'paul@email.com'),
(4, 'nicole', 'nicole', 'nicole', 'pinhal', ''),
(5, 'mark', 'mark', 'mark', 'white', 'mark@email.com'),
(6, 'roy', 'roy', 'roy', 'mullen', 'roy@email.com'),
(7, 'david', 'david', 'david', 'hill', 'david@email.com'),
(8, 'tom', 'tom', 'tom', 'red', 'tom@email.com'),
(9, 'peter', 'tom', 'peter', 'brown', 'po@email.com'),
(10, 'rer', ' ', 'er', 'erer', 'erer@dfd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`BookingID`),
  ADD KEY `users_fk` (`UserID`),
  ADD KEY `flight_id` (`flight_id`);

--
-- Indexes for table `listings`
--
ALTER TABLE `listings`
  ADD PRIMARY KEY (`flight_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `ind1` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `BookingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `listings`
--
ALTER TABLE `listings`
  MODIFY `flight_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `flight_fk` FOREIGN KEY (`flight_id`) REFERENCES `listings` (`flight_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_fk` FOREIGN KEY (`UserID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
