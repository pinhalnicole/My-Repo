<?php include 'inc/header.php'; ?>

    <div class="container">        
        <section class="content">
          <h2>Welcome</h2>
          <p>
            Welcome to the home of AirLines. Easily book a flight from Dublin to London.
          </p>
          <p>
            To book a flight, visit the <a href="listings.php">listings page</a> to find the right booking for you.
          </p>
        </section>
    </div>
    <?php include 'inc/footer.php'; ?>
    </div> <!-- end .wrapper -->
  </body>
</html>