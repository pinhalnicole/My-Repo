<?php include 'inc/header.php'; ?>
<!-- this page is shown when a new user registration has been succesfully completed -->

    <div class="container">  
        <section class="content">
          <h2>Done!</h2>
          <p>Your registration was<span style="font-weight:bold"> succesful.</span></p>
          <p>You can login  <a href="login.php">here</a></p>
        </section>
    </div>
    <?php include 'inc/footer.php'; ?>
    </div> <!-- end .wrapper -->
  </body>
</html>