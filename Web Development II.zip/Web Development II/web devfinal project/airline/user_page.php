<?php include 'inc/header.php'; ?>
<?php
   include('session.php');  //get session information
?>
<!-- user page where the user can look at her/his bookings and delete one or more booking -->
<html>
   <head>
      <title>Welcome </title>
   </head>
 
   <body>
      <div class="container">
		<section class="content">
		<!-- show the username of the user logged in and the logout link -->
			<p>Logged in as: <span style="font-weight:bold"><?php echo $login_session; ?></span> [<a href = "logout.php">Log Out</a>]</p><br>
			<h2>Hi <?php echo $login_session; ?>!</h2> 
		<?php
			// php script to delete the selected flight when the form is submitted
			if($_SERVER["REQUEST_METHOD"] == "POST") {

			//get the userid of the user logged in	
			//$_SESSION['login_user'] contains the username of the user logged in.
			$sql = "select userID from users where username='".$_SESSION['login_user']."'";
			$result =  mysqli_query($db,$sql);
			$row = mysqli_fetch_assoc($result);
			$user_id = $row['userID'];
			 
			// get the book id
			$book_id = mysqli_real_escape_string($db,$_POST['book_id']);
			
			//delete the selected bookings from the table bookings in the MYSQL database
			$sql_delete = "DELETE FROM bookings WHERE UserID = ".$user_id." and BookingID = ". $book_id; 
			mysqli_query($db,$sql_delete);   //execute the query
			header("location: user_page.php"); 	//refresh the page			 
			}
			?>
	 
          <p>
            Here you can see your current bookings.To book more flights select Listings from the menu or click <a href="listings.php?" class="btn btn-sm btn-success listing-book-button">Book a Flight</a> 
          </p>  
          <h3>The following are your current bookings.</h3>
		  <p>You can delete one of your booking by entering an existing booking id and press DELETE button. Non exisiting booking id will be ignored.</p>

		  <!-- form to delete a booking by entering a valid booking ID  -->          
		  <form action="" method="POST">
            <div class="form-group">
                <label for="book_id" ><span>Booking ID:</span>
					<!-- only integer numbers greater than zero are allowed  -->
                  <input type="number" min="1" step="1" required  name = "book_id" id="book_id" placeholder="enter number">
                  <button type="submit" class="btn btn-success">Delete Booking</button>
				  </label>
			  </div>
            </form>
          <h2>Your Current Bookings
		  		<?php 
				//script to get the number of bookings for the user
				$sql = "select * from listings inner join bookings on listings.flight_id = bookings.flight_id where bookings.UserID =  (select UserID from users where username='".$login_session."') order by bookings.Booking_date desc";
				$result = mysqli_query($db,$sql); 
				$count = mysqli_num_rows($result); 
				//display the number of current bookings for the user
				echo '<span style="font-weight:bold">('.$count.")</span>"; 
				?>
		  
		  </h2>

	        <div class="bus-listing-title">
              <span class="listing-id">Booking ID</span>
              <span class="listing-id">Flight ID</span>
              <span class="listing-from">From</span>
              <span class="listing-from">To</span>
              <span class="listing-dept-time">Dept. time</span>
              <span class="listing-arrival-time">Arr. time</span>
              <span class="listing-arrival-time">Booking time</span>
            </div>
	  
  	<?php    
		//display all the bookings of the users in a table
		//SQL query to get all the flights book by the user. It is a joint query between the table listings and bookings
		$sql = "select * from listings inner join bookings on listings.flight_id = bookings.flight_id where bookings.UserID =  (select UserID from users where username='".$login_session."') order by bookings.Booking_date desc";
		$result = mysqli_query($db,$sql);
	
		while($row = mysqli_fetch_assoc($result))
				{
				   echo '<div class="bus-listing">';
				   echo '<span class="listing-id">'.$row['BookingID'].'</span>';
				   echo '<span class="listing-id">'.$row['flight_id'].'</span>';
				   echo '<span class="listing-from">'.$row['flight_from'].'</span>';
				   echo '<span class="listing-from">'.$row['flight_to'].'</span>';
				   echo '<span class="listing-dept-time">'.$row['depart_time'].'</span>';
				   echo '<span class="listing-arrival-time">'.$row['arrival_time'].'</span>';
				   echo '<span class="listing-arrival-time">'.$row['Booking_date'].'</span>';
				   }
		
	?>
		</section>
	</div>  
   </body>
   <?php include 'inc/footer.php'; ?>
   
</html>
