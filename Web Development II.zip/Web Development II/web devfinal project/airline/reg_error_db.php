<?php include 'inc/header.php'; ?>
<html>
   <head>
      <title>Error - Registration </title>
   </head>
 
   <body>

    <div class="container">
        <section class="content">
          <h2>Ops...</h2>
          <p>There was a problem with your registration. <span style="font-weight:bold">Our database was not updated with your information</span></p>
          <p>Please try again to register  <a href="register.php">here</a></p>
        </section>
    </div>
    <?php include 'inc/footer.php'; ?>

    </div> <!-- end .wrapper -->
  </body>
</html>