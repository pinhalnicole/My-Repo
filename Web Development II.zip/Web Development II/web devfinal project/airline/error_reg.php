<?php include 'inc/header.php'; ?>
<!-- error page, shown if the registration failed because the username is already used -->
<html>
   <head>
      <title>Error - Registration </title>
   </head>
 
   <body>
    <div class="container">
        <section class="content">
          <h2>Ops...</h2>
          <p>There was a problem with your registration. <span style="font-weight:bold">The username entered is already in use.</span></p>
          <p>Please try again to register  <a href="register.php">here</a></p>
        </section>
    </div>

    <?php include 'inc/footer.php'; ?>
    </div> <!-- end .wrapper -->
  </body>
</html>