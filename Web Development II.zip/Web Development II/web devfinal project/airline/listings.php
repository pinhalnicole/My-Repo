<?php include 'inc/header.php'; ?>
<?php
   include('session.php');  //get session information
?>
<html> 
   <body>

    <div class="container">
        
        <section class="content">
		<?php   
		   if(isset($login_session)){  //check if a user is logged in
				if ($login_session=='admin')  //if the user is  "admin", show the listing page for the admin
				{
					header('location: listing_admin.php');  //go to the admin page
				}
			//show who is logged in
			echo '<p>Logged in as: <span style="font-weight:bold">'.$login_session.'</span> [<a href = "logout.php">Log Out</a>]</p><br>';
			}
		?>

          <h2>Flights Listings</h2>
		<?php   
		   if(isset($login_session)){  //if there is a user logged in , create the form to add a booking
			echo '<p>You can book a flight by entering the flight id and pressing the Book Now button.</p>';
			echo '<form action="" method="POST"><div class="form-group">';
			echo '<label for="flight_id" ><span>Flight ID: </span>';
			echo '<input type="number" min="1" step="1" required  name = "flight_id" id="flight_id" placeholder="enter number">';
            echo  '<button type="submit" class="btn btn-success">Book Now</button></label></div></form>';
			}
		?>

         <div class="bus-listing-title">
              <span class="listing-id">ID</span>
              <span class="listing-from">From</span>
              <span class="listing-to">To</span>
              <span class="listing-dept-time">Dept. time</span>
              <span class="listing-arrival-time">Arr. time</span>
            </div>
	<?php 
		//get the listings from the database and display them
      $sql = "SELECT * FROM listings";
      $result = mysqli_query($db,$sql);
	
		while($row = mysqli_fetch_assoc($result))
				{
				   echo '<div class="bus-listing">';
				   echo '<span class="listing-id">'.$row['flight_id'].'</span>';
				   echo '<span class="listing-from">'.$row['flight_from'].'</span>';
				   echo '<span class="listing-to">'.$row['flight_to'].'</span>';
				   echo '<span class="listing-dept-time">'.$row['depart_time'].'</span>';
				   echo '<span class="listing-arrival-time">'.$row['arrival_time'].'</span>';			   
				}
		
			//add a new booking if the form was submitted
			if($_SERVER["REQUEST_METHOD"] == "POST") {
	
			//get the userid of the user logged in
			//$_SESSION['login_user'] stores the username of the user logged in
			$sql = "select userID from users where username='".$_SESSION['login_user']."'";
			$result =  mysqli_query($db,$sql);
			$row = mysqli_fetch_assoc($result);
			$user_id = $row['userID'];
			
			date_default_timezone_set('Eire');  //set the timezone
			$time_now = date("Y-m-d h:i:s");  //get the current time (=time of the booking)
			$fl_id = $_POST['flight_id'];  //get the flight id from the form
			
			//update the table bookings in the database with the new booking for the current user
			$sql = "INSERT INTO `bookings` (`flight_id`, `UserID`, `Booking_date`) VALUES ('$fl_id', '$user_id', '$time_now')";
			if (mysqli_query($db, $sql)) {
				header('location: booking_confirmation.php');  //success page
			} else
			
				header('location: booking_error.php');  //error page
			}
	?> 
		</section>
    </div>

    <?php include 'inc/footer.php'; ?>

    </div> <!-- end .wrapper -->
  </body>
</html>