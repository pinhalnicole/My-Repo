<?php
   include('session.php');  //get session information
?>
<?php 
	//delete all messages from the list of messages
		$sql_delete = "DELETE FROM messages WHERE mid >0";   //this query will cancel all the messages, mid is a positive auto increment number
		$result = mysqli_query($db,$sql_delete);
		header('location: admin_page.php');  //go back to the admin page
?>