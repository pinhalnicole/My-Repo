<?php include 'inc/header.php'; ?>
<!-- error page displayed  if there was an error inserting the new booking -->

<html>
   <head>
      <title>Error - Booking </title>
   </head>

    <div class="container">
        <section class="content">
          <h2>Ops...</h2>
          <p>There was a problem with your booking. Check if you have already a booking on that flight<span style="font-weight:bold">Our database was not updated with your information</span></p>
          <p>Plase try again  <a href="listings.php">here</a></p>
        </section>
    </div>

    <?php include 'inc/footer.php'; ?>

    </div> <!-- end .wrapper -->
  </body>
</html>