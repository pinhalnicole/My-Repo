<?php include 'inc/header.php'; ?>
<?php include('session.php'); ?>
<!-- the page check if there is a logged user. If it is the admin, redirects to the admin profile page 
	 If it is a normal user, redirects to the normal user profile page -->

	 <html>
   <body>
    <div class="container">       
        <section class="content">
        <?php  
			//check if somebody is logged in. If it is the admin, go to admin page, otherwise go to user page
		   if(isset($login_session)){  //check if somebody is logged in by looking at the variable $login_session
			   if ($login_session=='admin')  //if the user is the admin...
			   {
					header('location: admin_page.php');  //redirects to the admin profile page
			   } else
			   {header('location: user_page.php');}	//otherwise show the normal user profile page
		}
			//if nobody is logged, display the text below
		?>
		
          <h2>Must be logged in</h2>      
          <p>You must be logged in to view this page.</p>

        </section>
    </div>
    <?php include 'inc/footer.php'; ?>
    </div> <!-- end .wrapper -->
  </body>
</html>