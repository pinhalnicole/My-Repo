<?php include 'inc/header.php'; ?>
<?php
   include('session.php');  //get session information
?>
<html>

   <head>
      <title>Admin page </title>
   </head>
   
   <body>
       <div class="container">
        
        <section class="content">
		
		<!-- show the username of the user logged in and the logout link -->
	  <p>Logged in as: <span style="font-weight:bold"><?php echo $login_session; ?></span> [<a href = "logout.php">Log Out</a>]</p><br>
      
	  <h2>Welcome to the Admin page</h2> 
          <p>
			There are
			<?php    
			  //get the number of bookings and flights and show them
			  $sql = "select * from bookings"; //get all the bookings
			  $result = mysqli_query($db,$sql); 
			  $count = mysqli_num_rows($result);
			  $sql = "select * from listings";  //get all the flights
			  $result = mysqli_query($db,$sql); 
			  $count_fl = mysqli_num_rows($result);
			  echo $count." active bookings and ".$count_fl." active flights" ?>
          </p>
          <p>
            You can add or modify the list of flights by clicking <a href="listings.php?" class="btn btn-sm btn-success listing-book-button">Manage Flights</a>
          </p>
		  <br>
		  
		<!-- this section show all the messages sent by the customers (only the admin can see them). 
			 the admin can also clear the list of messagegs -->
          <h3>
            Customers' messages
			<?php    
				//get the number of messages from the table messages
				$sql = "select * from messages order by mid asc";
				$result = mysqli_query($db,$sql); 
				$count = mysqli_num_rows($result);
				echo "(".$count." active)"; ?>
          </h3>
		  <p>To delete the list of messages press: 
					<!-- this is a link to a php script that delete all the messages -->
			<a href="delete_message.php?" class="btn btn-sm btn-success listing-book-button">Delete Message List</a>
		  </p>

		   <div class="bus-listing-title">
              <span class="listing-id">Message ID</span>
              <span class="listing-from">Author</span>
              <span class="message-text">Message Text</span>
            </div>
		
		<?php    
		//php script to get all the customers messages and show them in the HTML page
		$sql = "select * from messages order by mid asc";
		$result = mysqli_query($db,$sql);
	
		while($row = mysqli_fetch_assoc($result)) //loop over each message and display it
				{
				   echo '<div class="bus-listing">';
				   echo '<span class="listing-id">'.$row['mid'].'</span>';
				   echo '<span class="listing-from">'.$row['author'].'</span>';
				   echo '<span class="message-text">'.$row['message'].'</span>';
				}
		?>
		</section>
	</div>	  
   </body>
   <?php include 'inc/footer.php'; ?>
   
</html>
