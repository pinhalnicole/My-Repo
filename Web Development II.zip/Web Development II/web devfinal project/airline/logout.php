<?php
	//logout = destroy current session
   session_start();
   if(session_destroy()) {
      header("Location: index.php");
   }
?>