<?php include 'inc/header.php'; ?>
<!-- this page is displayed to confirm that the booking was saved correctly -->
<html>
   <body>
    <div class="container">
        <section class="content">
          <h2>Done!</h2>
          <p>
            Your booking was succesful. <span style="font-weight:bold">Have a nice trip!</span>
          </p>
          <p>
            You can see your bookings  <a href="user_page.php">here</a>.
            You can book more flights  <a href="listings.php">here</a>		
          </p>
        </section>
    <?php include 'inc/footer.php'; ?>
    </div> <!-- end .wrapper -->
  </body>
</html>