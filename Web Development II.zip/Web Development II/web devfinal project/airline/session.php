<?php
   include('config.php');  //script to connect to the database
   session_start();  //keep session
   if(isset($_SESSION['login_user'])){
   $login_session = $_SESSION['login_user'];}  //if a user is logged, store his username into the variable $login_session
?>