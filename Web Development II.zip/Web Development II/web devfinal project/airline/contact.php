<?php include 'inc/header.php'; ?>
<?php    
	include('config.php'); // config.php connects to the MYSQL database, return a variabl $db storing the connection 
?>  
<html>
   <head>
      <title>Contact US</title>
   </head>
 
   <body>

    <div class="container">        
        <section class="content">
          <h2>Contact Us</h2>
		
		<!-- form where the user can enter her/his name and a message -->
          <form action="" method="POST">
            <div class="form-group">
                <label for="contactName" class="col-sm-2 control-label">Name</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" required name="contactName" id="contactName" placeholder="Name"/>
                </div>
              </div>
              <br/><br/>
              <div class="form-group">
                <label for="contactMessage" class="col-sm-2 control-label">Message</label>
                <div class="col-sm-10">
                  <textarea name="contactMessage" id="contactMessage" required class="form-control" rows="3"></textarea>
                </div>
              </div>
              <br/><br/><br/>
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" class="btn btn-success">Submit</button>
                </div>
              </div>
            </form>
            <div class="safety"></div>
        </section>
    </div>

    <?php include 'inc/footer.php'; ?>
	
	<?php
		//php script to store the message and the author of the message in the table messages -->
		session_start(); 
		if($_SERVER["REQUEST_METHOD"] == "POST") {		//if the form has been submitted...  
			//get the name of the author and the message...
			$author = mysqli_real_escape_string($db,$_POST['contactName']);
			$message = mysqli_real_escape_string($db,$_POST['contactMessage']); 
	
			//execute an INSERT SQL query into the table messages
			$sql = "INSERT INTO `messages` (`mid`,`author`, `message`) VALUES (NULL, '$author', '$message')";
			if (mysqli_query($db, $sql)) {
				header("location: message_ok.php");  //query ok, go to confirmation page
				} else {
					header("location: index.php");	//error, go to error page
				}
			}		
	?>
	</div> <!-- end .wrapper -->
  </body>
</html>