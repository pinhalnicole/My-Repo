<?php include 'inc/header.php'; ?>
<!-- the page is displayed when a message from a customer has been correctly inserted in the database -->

<html>
   <head>
      <title>Message Sent!</title>
   </head>
 
   <body>    <div class="container">
        <section class="content">
          <h2>Done!</h2>
          <p>Your message has been sent succesful. <span style="font-weight:bold">Thank you!</span></p>
          <p>Why don't you take a look at our flights  <a href="listings.php">here</a>?</p>
        </section>
    </div>
    <?php include 'inc/footer.php'; ?>
    </div> <!-- end .wrapper -->
  </body>
</html>