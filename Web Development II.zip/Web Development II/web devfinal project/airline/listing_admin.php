<?php include 'inc/header.php'; ?>
<?php
    include('session.php');  //get session information
?>
<html>
   <head>
      <title>Flights Listing </title>
   </head>
   <body>
   
    <div class="container">      
        <section class="content">
		<?php
			//show the user logged in, if there is a user logged in...
			//$login_session is the username of the logged user, it is set by session.php
		   if(isset($login_session)){
			echo '<p>Logged in as: <span style="font-weight:bold">'.$login_session.'</span> [<a href = "logout.php">Log Out</a>]</p><br>';
			}
		?>

	<?php
	// script to delete the selected flight when the form is submitted
	   if($_SERVER["REQUEST_METHOD"] == "POST") {
			
			// get the flight id		  
			$flight_id = mysqli_real_escape_string($db,$_POST['flight_id']);
			
			//delete the selected flight from the listings table in the MYSQL database
			$sql_delete = "DELETE FROM listings WHERE flight_id = ". $flight_id; 
			mysqli_query($db,$sql_delete);   //execute the query
			header("location: listing_admin.php"); 	//refresh the page			 
	   }
?>

          <h2>Manage Flights Listing (Admin Page)</h2>
		  <!-- link to add a flight page -->
			<p>To add a new flight, press: 
				<a href="add_flight.php?" class="btn btn-sm btn-success listing-book-button">Add Flight</a>
			</p>
			<p>You can delete a flight by entering an existing flight id and press DELETE button. <br> Non exisiting flight ID will be ignored. <span style="font-weight:bold">WARNING: all bookings on that flight will be also deleted</span></p>
		  <!-- form to delete a flight by inserting a valid flight id -->
          <form action="" method="POST">
            <div class="form-group">
                <label for="flight_id" ><span>Flight ID:</span>
					<!-- only integer numbers greater than zero are allowed  -->
                  <input type="number" min="1" step="1" required  name = "flight_id" id="flight_id" placeholder="enter number">
                  <button type="submit" class="btn btn-success">Delete Flight</button>
				  </label>
			  </div>
            </form>
			
          <h2><br>Current Flights Listings</h2>
			<!-- headers of the listings  -->	  
			<div class="bus-listing-title">
				  <span class="listing-id">ID</span>
				  <span class="listing-from">From</span>
				  <span class="listing-to">To</span>
				  <span class="listing-dept-time">Dept. time</span>
				  <span class="listing-arrival-time">Arr. time</span>
				</div>

	<?php 
		//get all the listings from the table listings in the MYSQL database and display them in the HTML
      $sql = "SELECT * FROM listings order by flight_id desc";
      $result = mysqli_query($db,$sql);
	
		while($row = mysqli_fetch_assoc($result))
				{				   
				   echo '<div class="bus-listing">';
				   echo '<span class="listing-id">'.$row['flight_id'].'</span>';
				   echo '<span class="listing-from">'.$row['flight_from'].'</span>';
				   echo '<span class="listing-to">'.$row['flight_to'].'</span>';
				   echo '<span class="listing-dept-time">'.$row['depart_time'].'</span>';
				   echo '<span class="listing-arrival-time">'.$row['arrival_time'].'</span>';
				}
	?>  
        </section>
    </div>	
    <?php include 'inc/footer.php'; ?>
    </div> <!-- end .wrapper -->
  </body>
</html>