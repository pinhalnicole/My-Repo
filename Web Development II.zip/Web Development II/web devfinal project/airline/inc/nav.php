<nav>
  <ul>
    <li>
      <a href="index.php" class="menu-link">Home</a>
    </li>
    <li>
      <a href="profile.php" class="menu-link">Profile</a>
    </li>
    <li>
      <a href="listings.php" class="menu-link">Listings</a>
    </li>
    <li>
      <a href="contact.php" class="menu-link">Contact</a>
    </li>
    -
    <li>
      <a href="login.php" class="menu-link">Log In</a>
    </li>

  </ul>
</nav>