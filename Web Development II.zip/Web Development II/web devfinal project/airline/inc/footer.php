<footer>
	<p>
		Airline Application &copy; <?php echo Date('Y'); ?>
		<a class="pull-right" href="contact.php">Get in touch</a>
	</p>
</footer>