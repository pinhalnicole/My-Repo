<?php

	echo 'code to handle booking form goes in this file';

	echo '<br>';
	echo '<br>';
	
	echo 'booking id: ' . $_GET['listing'];