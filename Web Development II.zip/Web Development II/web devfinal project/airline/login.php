<?php include 'inc/header.php'; ?>
<?php    include('config.php'); //connect to the database?>  
<!-- login page -->

<html>
   <head>
      <title>Login Page</title>
   </head>
   <body>

    <div class="container">        
        <section class="content">
          <h2>Login</h2>
          <!-- login form, all fields required -->
          <form action="" method="POST">

            <div class="form-group">
                <label for="username" class="col-sm-2 control-label">Username</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name = "username" id="username" required placeholder="username"/>
                </div>
              </div>
              <br/><br/>
              <div class="form-group">
                <label for="password" class="col-sm-2 control-label">Password</label>
                <div class="col-sm-10">
                  <input type="password" name = "password" class="form-control" id="password" required placeholder="password"/>
                </div>
              </div>
              <br/><br/>        
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" class="btn btn-success">Login</button>
				  <a href="register.php" class="btn btn-success">Sign Up</a></div>  
              </div>
            </form>

            <div class="safety"></div>
        </section>

    </div>

    <?php include 'inc/footer.php'; ?>
	
	<?php
		//php script to check if the login was ok
		session_start();
   
		if($_SERVER["REQUEST_METHOD"] == "POST") {
			
			// store the username and password submitted from the FORM into two variables 
			$myusername = mysqli_real_escape_string($db,$_POST['username']);
			$mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
		//check if the username and password are correct by checking the MYSQL database, table users
		
		$sql = "SELECT UserID FROM users WHERE username = '$myusername' and password = '$mypassword'";
		$result = mysqli_query($db,$sql);  //execute query
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		  
		$count = mysqli_num_rows($result);  //get the number of  rows returned by the query
		//the count must be 1, If it is 0, the username or password are not correct
		
		
		if($count == 1) {  //if count = 1 the password and username are correct, the user can log in
			$_SESSION['login_user'] = $myusername;		//store the username of the user into the active SESSION data 
			
			if ($myusername=='admin')  //if it is the admin, redirect to the admin page, otherwise show the normal users profile page
				{
					header("location: admin_page.php");		//admin page
				} else
				{   header("location: user_page.php");}  	//normal users
			}
			else {		//count is not 1, there was an error, display a message
			 echo "Wrong username or password. Please retry.";
      }
   }
?>
    </div> <!-- end .wrapper -->
  </body>
</html>