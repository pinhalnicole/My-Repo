<?php include 'inc/header.php'; ?>
<?php    include('config.php'); //config.php is a php script to connect to the database, it returns a variable storing the connection to the database named $db ?>
<!-- Registration page -->

<html>
   <head>
      <title>Registration </title>
   </head>
   <body>
    <div class="container">        
        <section class="content">
          <h2>Enter your details to register</h2>
		  <!-- form to enter the information about the new user to register. All fields are required -->

          <form action="" method="POST">

            <div class="form-group">
                <label for="username" class="col-sm-2 control-label">Username</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" required name = "username" id="username" placeholder="username"/>
                </div>
              </div>
              <br/><br/>
              <div class="form-group">
                <label for="password" class="col-sm-2 control-label">Password</label>
                <div class="col-sm-10">
                  <input type="password" name = "password" class="form-control" required id="password" placeholder="password"/>
                </div>
              </div>
              <br/><br/>
              <div class="form-group">
                <label for="name" class="col-sm-2 control-label">First Name</label>
                <div class="col-sm-10">
                  <input type="text" name = "name" class="form-control" required id="name" placeholder="name"/>
                </div>
              </div>
              <br/><br/>
              <div class="form-group">
                <label for="lastname" class="col-sm-2 control-label">Last name</label>
                <div class="col-sm-10">
                  <input type="text" name = "lastname" class="form-control" required id="lastname" placeholder="lastname"/>
                </div>
              </div>
              <br/><br/>
              <div class="form-group">
                <label for="lastname" class="col-sm-2 control-label">Your email</label>
                <div class="col-sm-10">
                  <input type="email" name = "email" class="form-control" id="email" required placeholder="email"  />
                </div>
              </div>
              <br/><br/>        
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" class="btn btn-success">Register</button>
              </div>
            </form>
            <div class="safety"></div>
        </section>
    </div>

    <?php include 'inc/footer.php'; ?>
	
	<?php
		//php script to register the new user.
		session_start();
   
		if($_SERVER["REQUEST_METHOD"] == "POST") {  //if the form has been submitted..
		
		// store username and password (sent from the form) into 2 variables 
		$myusername = mysqli_real_escape_string($db,$_POST['username']);
		$mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
		//check if the username is already used
		$sql = "SELECT UserID FROM users WHERE username = '$myusername'";
		$result = mysqli_query($db,$sql);
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		$count = mysqli_num_rows($result);	//count the returning rows and store into the variable $count
      
		// If the count is 1 , it means that the username is already in the database, display an error page	
		if($count == 1) 
			{
				header("location: error_reg.php");  //username already used, display error page
			} 
			else
			{   
				//save the new user in the database
				//get all the information from the submitted FORM
				$myusername = mysqli_real_escape_string($db,$_POST['username']);
				$mypassword = mysqli_real_escape_string($db,$_POST['password']); 
				$myemail = mysqli_real_escape_string($db,$_POST['email']); 
				$firstname = mysqli_real_escape_string($db,$_POST['name']); 
				$lastname = mysqli_real_escape_string($db,$_POST['lastname']); 
				
				//excute an INSERT SQL query into the table users in the MYSQL DB
				$sql = "INSERT INTO `users` (`userID`, `username`, `password`, `u_name`, `u_surname`, `email`) VALUES (NULL, '$myusername', '$mypassword', '$firstname', '$lastname', '$myemail');";
				if (mysqli_query($db, $sql)) 
					{
						header("location: reg_ok.php");  //query ok, display registration confermation page
					} else {
						header("location: reg_error_db.php");  //error occurred, display error page
					}
				}  
		   }
	?>
    </div> <!-- end .wrapper -->
  </body>
</html>