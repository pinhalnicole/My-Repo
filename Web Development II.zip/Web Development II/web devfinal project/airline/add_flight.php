<?php include 'inc/header.php'; ?>
<?php    include('config.php'); //connect to the database, return the variable $db?>  
<html>
   <head>
      <title>Add a flight </title>
   </head>
 
   <body>
    <div class="container">
        <section class="content">
          <h2>Enter the details of the new flight</h2>
          
          <form action="" method="POST">
            <div class="form-group">
                <label for="text" class="col-sm-2 control-label">From</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" required name = "from" id="from" placeholder="From"/>
                </div>
              </div>
              <br/><br/>
              <div class="form-group">
                <label for="text" class="col-sm-2 control-label">To</label>
                <div class="col-sm-10">
                  <input type="text" name = "destination" required class="form-control" id="destination" placeholder="To"/>
                </div>
              </div>
              <br/><br/>
              <div class="form-group">
                <label for="departure" class="col-sm-2 control-label">Departure Time</label>
                <div class="col-sm-10">
                  <input type="time" name = "departure" required class="form-control" id="departure" placeholder="HH:MM"/>
                </div>
              </div>
              <br/><br/>
              <div class="form-group">
                <label for="arrival" class="col-sm-2 control-label">Arrival Time</label>
                <div class="col-sm-10">
                  <input type="time" name = "arrival" required class="form-control" id="arrival" placeholder="HH:MM"/>
                </div>
              </div>
              <br/><br/>
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" class="btn btn-success">Add Flight</button>
              </div>
            </form>

            <div class="safety"></div>
        </section>
    </div>
    <?php include 'inc/footer.php'; ?>
	
	<?php
		session_start(); //get information about session
		
		//get the information from the HTML form, store in variables and insert into the DB
		if($_SERVER["REQUEST_METHOD"] == "POST") {
 		
			//save the new flight in the database
			//save the data from the form into some variables
			$from = mysqli_real_escape_string($db,$_POST['from']);
			$to = mysqli_real_escape_string($db,$_POST['destination']); 
			$departure = mysqli_real_escape_string($db,$_POST['departure']); 
			$arrival = mysqli_real_escape_string($db,$_POST['arrival']); 	
		
			//insert into the listings table
			$sql = "INSERT INTO `listings` (`flight_id`,`flight_from`, `flight_to`, `depart_time`, `arrival_time`) VALUES (NULL, '$from', '$to', '$departure', '$arrival');";
			if (mysqli_query($db, $sql)) {
				header("location: listing_admin.php");  //if everything was ok, go back to the flight lisiting
				} else {
				header("location: error_flight.php");  //error message
				}
			}
?>
    </div> <!-- end .wrapper -->
  </body>
</html>