﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPAssignment
{
    class Program
    {
        // Dictionary to store Customers, where the key is the customer surname
        // and the value is a list of customers with the same surname as the key
        private static Dictionary<String, List<Customer>> customerDict = new Dictionary<string, List<Customer>>();

        // Dictionary to store a list of all loans taken by various customers
        // Key = Customer, Value = List of loans taken by the customer
        private static Dictionary<Customer, List<Loan>> loanDict = new Dictionary<Customer, List<Loan>>();

        static void Main(string[] args)
        {
            int ch;
            do
            {
                Console.WriteLine("**********Loans2Go************");
                Console.WriteLine("************Menu**************");
                Console.WriteLine("Enter 1 to create a new loan Customer");
                Console.WriteLine("Enter 2 to apply for a loan");
                Console.WriteLine("Enter 3 to search for a registered customers");
                Console.WriteLine("Enter 4 to print all registered customers");
                Console.WriteLine("Enter 5 to check loans applied by a customer");
                Console.WriteLine("Enter 6 to exit");
                Console.WriteLine("******************************");
                Console.WriteLine("******************************");

                ch = Convert.ToInt32(Console.ReadLine());

                handleChoice(ch);
            } while (ch != 6);
        }

        private static void handleChoice(int ch)
        {
            // handling the selection made by the customer
            switch(ch)
            {
                case 1:
                    createNewCustomer();
                    break;
                case 2:
                    Console.WriteLine("Enter the Lastname of the customer that wants to apply the loan");
                    string lastName = Console.ReadLine();

                    List<Customer> cust = getCustomersByLastName(lastName);
               
                    if (cust.Count() == 1)
                    {
                        handleLoanApplication(cust.ElementAt(0));
                    }
                    else if(cust.Count() > 1)
                    {
                        Console.WriteLine("There are more than one customer with the lastname- "
                            + lastName + ". Please enter the PPSN number of the customer that"
                            + " wants to apply for the loan");
                        string pps = Console.ReadLine();
                        int customerFound = 0;
                        foreach (var c in cust) {
                            if (c.PPSN == pps)
                            {
                                customerFound = 1;
                                handleLoanApplication(c);
                                break;
                            }
                        }
                        if(customerFound == 0)
                        {
                            Console.WriteLine("No customer with the surname " + lastName + " and " +
                                "pps number " + pps + " exists in our records! Please try again.");
                        }
                    }
                    
                    break;
                case 3:
                    // Searching a customer by their surname
                    Console.WriteLine("Enter the surname of the registered customer to lookup");
                    string surname = Console.ReadLine();
                    if (customerDict.ContainsKey(surname))
                    {   
                        foreach(var c in customerDict[surname])
                        {
                            // printing all customers with the provided surname
                            Console.WriteLine(c.ToString());
                        }
                    }
                    break;
                case 4:
                    // Printing all registered customers
                    foreach(KeyValuePair<String, List<Customer>>  cDict in customerDict)
                    {
                        foreach(var c in cDict.Value)
                        {
                            Console.WriteLine(c.ToString());
                        }
           
                    }
                    break;
                case 5:
                    Console.WriteLine("Enter the surname of the registered customer to lookup");
                    string ln = Console.ReadLine();
                    // Displays the loans taken out by a customer with the provided surname
                    displayCustomerLoans(ln);
                    break;
                case 6:
                    Console.WriteLine("Bye Bye");
                    break;
                default:
                    Console.WriteLine("Invalid choice, please try again");
                    break;
            }
        }

        private static List<Customer> getCustomersByLastName(string lastName)
        {
            List<Customer> cust = new List<Customer>();
            try
            {
                cust = customerDict[lastName];
            }
            // Catch exception if key with the provided customer surname doesn't exist
            catch (KeyNotFoundException e)
            {
                Console.WriteLine("No Customer exists with the supplied surname. Try again");

            }
            return cust;
        }

        private static void displayCustomerLoans(String lastName)
        {
            // Prints the loans registered against a customer 
            List<Customer> cust = getCustomersByLastName(lastName);
            if (cust.Count > 0)
            {
                if (loanDict.ContainsKey(cust.ElementAt(0)))
                {
                    Console.WriteLine("The loans for customer with lastName- " + lastName);
                    List<Loan> loans = loanDict[cust.ElementAt(0)];

                    foreach (var loan in loans)
                    {
                        Console.WriteLine("*******************************");
                        Console.WriteLine(loan.ToString());
                        Console.WriteLine("*******************************");
                    }
                } else
                {
                    Console.WriteLine("No loans have been applied by the customer yet");
                }
            } 
        }

        private static void createNewCustomer()
        {
            Console.WriteLine("Enter the firstname of the customer");
            string fname = Console.ReadLine();
            Console.WriteLine("Enter the lastname of the customer");
            string lname = Console.ReadLine();
            Console.WriteLine("Enter the DOB of the customer");
            string dob = Console.ReadLine();
            Console.WriteLine("Enter the PPSN of the customer");
            string ppsn = Console.ReadLine();
            Console.WriteLine("Enter the address of the customer");
            string address = Console.ReadLine();
            Console.WriteLine("Enter the salary of the customer");
            double salary = Convert.ToDouble(Console.ReadLine());
            // creating new customer
            Customer customer = new Customer(fname, lname, dob, ppsn, address, salary);
            // Indexing the customer in a dictionary with lastname as the key
            if (!customerDict.ContainsKey(lname))
            {
                customerDict[lname] = new List<Customer>();
                customerDict[lname].Add(customer);
            }
            else
            {
                customerDict[lname].Add(customer);
            }
        }

        private static void handleLoanApplication(Customer customer)
        {
            // Get loan details
            Console.WriteLine("**********Loans2Go****************");
            Console.WriteLine("************New-Loan**************");
            Console.WriteLine("Enter the correct option corresponding to the loan you" +
                " would like to apply");
            Console.WriteLine("1. Home Improvement Loan ");
            Console.WriteLine("2. Morgage Loan");
            Console.WriteLine("3. Car Loan");
            Console.WriteLine("4. Sundry Loan");
            Console.WriteLine("5. Student Loan");

            int ch = Convert.ToInt32(Console.ReadLine());

            // creates a loan application
            makeLoanApplication(ch, customer);

            }

        private static void makeLoanApplication(int ch, Customer customer)
        {
            switch(ch)
            {
                case 1:
                    Console.WriteLine("Enter the term of the Home Improvement loan in months");
                    int homeImproveTerm = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter the money to be borrowed");
                    double homeImproveInitialLoanValue = Convert.ToDouble(Console.ReadLine());
                    double homeImproveCurrentOutstandingLoanValue = homeImproveInitialLoanValue;
                   
                    HomeImprovementLoan homeImproveLoan = new HomeImprovementLoan(homeImproveTerm, homeImproveInitialLoanValue, homeImproveCurrentOutstandingLoanValue,
                        customer);

                    if (homeImproveLoan.meetsLoanConditions())
                    {
                        Console.WriteLine("Congratulations! The loan has been approved");
                        // If loan conditions are met, add the loan to the dictionary
                        addLoanToCustomerLoans(customer, homeImproveLoan);
                    }
                    else
                    {
                        Console.WriteLine("Unfortunatly the minimum conditions for the loan weren't met" +
                            "the loan was not approved");
                    }
                    break;
                case 2:
                    Console.WriteLine("Enter the term of the Mortgage in months");
                    int term = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter the money to be borrowed");
                    double initialLoanValue = Convert.ToDouble(Console.ReadLine());
                    double currentOutstandingLoanValue = initialLoanValue;

                    Console.WriteLine("Enter the current asset Value");
                    double currentAssetValue = Convert.ToDouble(Console.ReadLine());

                    Mortgage morgage = new Mortgage(term, initialLoanValue, currentOutstandingLoanValue,
                        customer, currentAssetValue);

                    if (morgage.meetsLoanConditions())
                    {
                        Console.WriteLine("Congratulations! The loan has been approved");
                        // If loan conditions are met, add the loan to the dictionary
                        addLoanToCustomerLoans(customer, morgage);
                    }
                    else
                    {
                        Console.WriteLine("Unfortunatly the minimum conditions for the loan weren't met" +
                            "the loan was not approved");
                    }
                    break;
                case 3:
                    Console.WriteLine("Enter the term of the car loan in months");
                    int carTerm = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter the money to be borrowed");
                    double carInitialLoanValue = Convert.ToDouble(Console.ReadLine());
                    double carCurrentOutstandingLoanValue = carInitialLoanValue;

                    Console.WriteLine("Enter the current asset Value");
                    double carCurrentAssetValue = Convert.ToDouble(Console.ReadLine());

                    Car carLoan = new Car(carTerm, carInitialLoanValue, carCurrentOutstandingLoanValue,
                        customer, carCurrentAssetValue);

                    if (carLoan.meetsLoanConditions())
                    {
                        Console.WriteLine("Congratulations! The loan has been approved");
                        // If loan conditions are met, add the loan to the dictionary
                        addLoanToCustomerLoans(customer, carLoan);
                    }
                    else
                    {
                        Console.WriteLine("Unfortunatly the minimum conditions for the loan weren't met" +
                            ", the loan was not approved");
                    }
                    break;
                case 4:
                    Console.WriteLine("Enter the term of the Sundry loan in months");
                    int sundryTerm = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter the money to be borrowed");
                    double sundryInitialLoanValue = Convert.ToDouble(Console.ReadLine());
                    double sundryCurrentOutstandingLoanValue = sundryInitialLoanValue;

                    Sundry sundryLoan = new Sundry(sundryTerm, sundryInitialLoanValue, sundryCurrentOutstandingLoanValue,
                        customer);

                    if (sundryLoan.meetsLoanConditions())
                    {
                        Console.WriteLine("Congratulations! The loan has been approved");
                        // If loan conditions are met, add the loan to the dictionary
                        addLoanToCustomerLoans(customer, sundryLoan);
                    }
                    else
                    {
                        Console.WriteLine("Unfortunatly the minimum conditions for the loan weren't met" +
                            "the loan was not approved");
                    }

                    break;
                case 5:
                    Console.WriteLine("Enter the term of the car loan in months");
                    int studentTerm = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter the money to be borrowed");
                    double studentInitialLoanValue = Convert.ToDouble(Console.ReadLine());
                    double studentCurrentOutstandingLoanValue = studentInitialLoanValue;

                    Console.WriteLine("Enter the current asset Value");
                    double studentCurrentAssetValue = Convert.ToDouble(Console.ReadLine());

                    Student studentLoan = new Student(studentTerm, studentInitialLoanValue, studentCurrentOutstandingLoanValue,
                        customer, studentCurrentAssetValue);

                    if (studentLoan.meetsLoanConditions())
                    {
                        Console.WriteLine("Congratulations! The loan has been approved");
                        // If loan conditions are met, add the loan to the dictionary
                        addLoanToCustomerLoans(customer, studentLoan);
                    }
                    else
                    {
                        Console.WriteLine("Unfortunatly the minimum conditions for the loan weren't met" +
                            ", the loan was not approved");
                    }
                    break;
                default:
                    Console.WriteLine("Invalid choice, try again");
                    break;
            }
        }

        private static void addLoanToCustomerLoans(Customer customer, Loan loan)
        {
            if (!loanDict.ContainsKey(customer))
            {
                // if the dictionary has no key matching the customer, 
                // create a key, value pair with a list of customer loans
                // as the value
                loanDict[customer] = new List<Loan>();
                loanDict[customer].Add(loan);
            }
            else
            {

                // if the dictionary already contains the customer key, add the loan in the
                // list of customer loans
                loanDict[customer].Add(loan);
            }
        }
        
    }
}
