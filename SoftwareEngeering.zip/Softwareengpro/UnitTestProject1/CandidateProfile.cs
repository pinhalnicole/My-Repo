﻿using System;

namespace RecrutingApplication
{
    class CandidateProfile
    {
        //Declarations of Variables of the class

        //Unique ID for each Candidate
        int candidateId;
        string name;
        string address;
        DateTime dateOfBirth;
        string qualification;
        string experience;
        int marksOfTest;
        int interviewID;
        int interviewMarks;
        string result;


        //Method to get details of the candidate for creating Candidate Profile in the system
        //candidate is asked to put the input then candiate profile is created
        void getCandidateProfile()
        {
            //For getting input from the user, a message is displayed on the screen asking for relevant information and then stored in the appropriate variables
            Console.WriteLine("Welcome to Recruiting Process");
            Console.WriteLine("\nPlease Complete the Candidate Profile");
            Console.WriteLine("\nPlease enter Candidate Name: ");
            name = Console.ReadLine();
            Console.WriteLine("\nPlease enter Address of the Candidate: ");
            address = Console.ReadLine();
            Console.WriteLine("\nPlease enter Date of Birth of the Candidate in the format DD-MM-YY: ");
            dateOfBirth = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("\nPlease enter qualifications of the candidate: ");
            qualification = Console.ReadLine();
            Console.WriteLine("\nPlease enter Experience of the Candidate: ");
            experience = Console.ReadLine();

        }

        //Method to Display Candidate profile to the user (Candidate, HR, Interviewr)
        //second method is show candidate profile where the candidate details is shown on the screen
        void showCandidateProfile()
        {
            //Candidate Profile displayed on the screen with all the fields and a message saying Candidate has been registered Successfully
            Console.WriteLine("\nCandidate  Registered Successfully");
            Console.WriteLine("\nCANDIDATE  PROFILE");
            Console.WriteLine("\nCandidate Name: " + name);
            Console.WriteLine("\nCandidate Id: " + candidateId);
            Console.WriteLine("\nAdress of the Candidate: " + address);
            Console.WriteLine("\nDate of Birth: " + dateOfBirth);
            Console.WriteLine("\nQualifications of the candidate: " + qualification);
            Console.WriteLine("\nExperience of Candidate: " + experience);


            //If the reult is not declared yet, that means Candidate is still undergoing the process, so the result field shall not be displayed
            if (result != null)
            {
                // if results is not null results is displayed
                Console.WriteLine("\nResult: " + result);

            }

        }





        //Method to get the details about the Test from the user (Person conducting the Test)
        void getTestDetails()
        {
            //For getting the Test details from the user, a message is displayed on the screen asking for Test marks and the value is stored in the variable
            Console.WriteLine("\nPlease enter the marks obtained by Candidate for Written Test: ");
            marksOfTest = int.Parse(Console.ReadLine());
        }


        //Method to display Test details on to the screen to the user (HR, Interviewer)
        public string showTestDetails(int marksOfTest)
        {
            //Marks obtained by the candidate in Test are displayed in the screen to the user
            return "\nMarks Obtained by the Candidate in the written Test are: " + marksOfTest;

        }


        //Method to get the details of the Interview from the user (Interviewer)
        void getInterviewDetails()
        {
            //For getting the details of the Interview from the user, a message is displayed on the screen and value is stored in the appropriate variable.
            Console.WriteLine("\nPlease enter the intervie ID: ");
            interviewID = int.Parse(Console.ReadLine());
            Console.WriteLine("\nPlease enter the marks obtained by Candidate in interview: ");
            interviewMarks = int.Parse(Console.ReadLine());
        }


        //Method to display Inteview Details on to the screen to the user (HR, Interviewer)
        void showInterviewDetails()
        {
            //The interview details are displayed on the screen to the user.
            Console.WriteLine("Interview Details");
            Console.WriteLine("\nInterviewID id: " + interviewID);
            Console.WriteLine("\nMarks obtained by Candidate in the Interview: " + interviewMarks);

        }



        //Method for calculating and displaying the resul, based on Test and Interview marks
        public string getFinalResult(int marksOfTest, int interviewMarks)
        {
            //If the total marks obtained by the candidate is above 70% then the candidate result is Selected.
            if ((marksOfTest + interviewMarks) > 140)
            {
                //The candidate result is stored in the variable result
                result = "Candidate Selected";
            }

            //If the total marks obtained by the candidate are less than 70, the Candidate is Rejected.
            else
            {
                //The candidate result is stored in the variable result
                result = "Candidate Rejected";
            }
            return result;

        }


        //Main Mehtod, the entry point of the program (program execution starts from this point)
        static void Main()
        {
            CandidateProfile obj = new CandidateProfile();
            obj.getCandidateProfile();
            obj.showCandidateProfile();
            obj.getInterviewDetails();
            obj.showInterviewDetails();
            obj.getTestDetails();
            Console.WriteLine(obj.showTestDetails(obj.marksOfTest));
            //After calculation, the final result is displayed on the screen to the user
            Console.WriteLine("The final result is: " +
            obj.getFinalResult(obj.marksOfTest, obj.interviewMarks));
            Console.ReadKey();
        }
    }
}
