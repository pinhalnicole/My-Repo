﻿// unit test class
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RecrutingApplication
{
    [TestClass]
    public class CandidateProfileTest
    {
        [TestMethod]
        public void showFinalResultTest()
        {
            CandidateProfile ob = new CandidateProfile();

            Console.WriteLine("Testing when candidate is not selected");
            int marksOfTest = 70;
            int interviewMarks = 70;
            string expected = "Candidate Rejected";
            string actual = ob.getFinalResult(marksOfTest, interviewMarks);

            Assert.AreEqual(expected, actual);

            Console.WriteLine("Testing when candidate is selected");
            marksOfTest = 80;
            interviewMarks = 70;
            expected = "Candidate Selected";
            actual = ob.getFinalResult(marksOfTest, interviewMarks);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void showTestDetailsTest()
        {
            CandidateProfile ob = new CandidateProfile();
            int marksOfTest = 70;

            string expected = "\nMarks Obtained by the Candidate in the written Test are: " + marksOfTest;
            Assert.AreEqual(ob.showTestDetails(70), expected);
        }
    }
}
